# P507-29.09.2019

CSS introduction:

https://www.w3schools.com/css/css_intro.asp

https://www.w3schools.com/css/css_selectors.asp

https://www.w3schools.com/css/css_colors.asp

https://www.w3schools.com/css/css_background.asp

https://www.w3schools.com/css/css_border.asp

https://www.w3schools.com/css/css_dimension.asp

https://www.w3schools.com/css/css_margin.asp

https://www.w3schools.com/css/css_padding.asp

https://www.w3schools.com/css/css_display_visibility.asp

https://www.w3schools.com/css/css_float.asp



Tapshiriq:

Tapshiriq.png-ye uygun CV-nizi yigmaq
